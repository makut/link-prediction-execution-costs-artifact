"""Finite read-only YT ingress and unchanged public-input preparation.

Only an explicitly admitted fresh pod may execute this file. No scientific
benchmark, model scoring, package installation or YT mutation is performed.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import os
import queue
import shutil
import signal
import socket
import struct
import subprocess
import sys
import threading
import time

BASE = Path('/home/jovyan/seal_revision_20261124')
HERE = Path(__file__).resolve().parent
EXPECTED_HERE = BASE / 'revision_inputs_20261126_v3_code'
HOSTNAME = 'seal-window-repeats-20261126-0'
POD_UID = '98718cc9-f0cb-47b7-b54f-d66f737f1337'
STS_UID = '8da7f488-7109-4d58-80db-8b8fdf7f3c13'
OUT = BASE / 'results/revision_gpu_inputs_20261126_v3'
PREVIOUS_OUT = BASE / 'results/revision_gpu_inputs_20261126_v2'
RANGE_BYTES = 256 << 20
DOWNLOAD_WORKERS = 4
RANGE_ATTEMPTS = 3
REQUEST_TIMEOUT_MS = 120000
RAW_YT = '//home/ai-test/renat.aminov/citations2/raw/ogbl_citations2.zip'
FRIENDSTER_YT = '//home/ucp-research/projects/graph_baselines/friendster/csr'
CHUNK = 1 << 20


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path, check=lambda: None):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(CHUNK), b''):
            check()
            h.update(block)
    return h.hexdigest()


def atomic_json(path, value):
    path = Path(path)
    temp = path.with_name(path.name + '.tmp-' + str(os.getpid()) + '-' + str(time.time_ns()))
    with temp.open('x') as output:
        json.dump(value, output, indent=2, allow_nan=False)
        output.write('\n')
        output.flush()
        os.fsync(output.fileno())
    os.replace(temp, path)


def process_identity(pid):
    path = Path('/proc') / str(pid)
    try:
        fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
        return {'pid': pid, 'state': fields[0], 'start_ticks': int(fields[19])}
    except FileNotFoundError:
        return None


def arguments(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--expected-uid', type=int, required=True)
    p.add_argument('--expected-pod-uid', required=True)
    p.add_argument('--expected-sts-uid', required=True)
    p.add_argument('--hours', type=float, default=1.5)
    p.add_argument('--max-disk-gib', type=float, default=90)
    p.add_argument('--disk-reserve-gib', type=float, default=4)
    p.add_argument('--stage-wheelhouse', action='store_true')
    p.add_argument('--preparer-python', default='/opt/python/bin/python3')
    return p.parse_args(argv)


def admission(args):
    require(sys.platform == 'linux', 'Linux pod required')
    require(socket.gethostname() == HOSTNAME, 'Unexpected pod hostname')
    require(os.getuid() == args.expected_uid, 'Unexpected Unix UID')
    require(HERE == EXPECTED_HERE and BASE.resolve() == BASE, 'Unexpected source/base path')
    require(Path('/home/jovyan').is_dir() and BASE.is_dir(), 'Expected pod home/base missing')
    require(not OUT.exists() and not OUT.is_symlink(), 'A bootstrap output already exists; no retry')
    require(0 < args.hours <= 1.5 and 0 < args.max_disk_gib <= 90, 'Finite limits exceed admission')
    require(args.disk_reserve_gib >= 4, 'At least 4GiB free reserve required')
    require(args.expected_pod_uid == POD_UID and args.expected_sts_uid == STS_UID, 'Pinned Kubernetes UID launch bindings differ')
    observed = os.environ.get('POD_UID')
    if observed:
        require(observed == args.expected_pod_uid, 'Downward-API pod UID differs from admission')
    python = Path(args.preparer_python)
    require(python.is_absolute() and python.is_file(), 'Preparer Python is missing')
    require(str(python) == '/opt/python/bin/python3' or python.is_relative_to(BASE), 'Unexpected preparer Python path')
    fresh_paths = ['data/citation2',
                   'data/friendster_DOWNLOAD_COMPLETE.json', 'data/input_download_manifest.json']
    if args.stage_wheelhouse:
        fresh_paths.append('pencil_bridge_wheelhouse_linux_cp310_matched.tgz')
    for rel in fresh_paths:
        target = BASE / rel
        require(not target.exists() and not target.is_symlink(), 'Preserve existing input path: ' + rel)
    fr_root = BASE / 'data/friendster/full_csr'
    require(fr_root.is_dir() and not fr_root.is_symlink(), 'Expected previous Friendster download directory')
    require({p.name for p in fr_root.iterdir()} <= {'edge_starts.bin', 'edge_ends.bin.partial'},
            'Unexpected prior input; preserve without retry')
    require((fr_root/'edge_starts.bin').is_file() and not (fr_root/'edge_starts.bin').is_symlink(),
            'Previous canonical offsets required')
    require(PREVIOUS_OUT.is_dir() and not PREVIOUS_OUT.is_symlink(), 'Previous v2 evidence missing')
    for name in ('FAILED.json','input_download_manifest.json'):
        path = PREVIOUS_OUT/name
        require(path.is_file() and not path.is_symlink() and path.stat().st_size <= (1 << 20),
                'Bounded previous v2 failure/download receipt required')
    return {'hostname': HOSTNAME, 'uid': os.getuid(), 'pod_uid_root_launch_binding': args.expected_pod_uid,
            'statefulset_uid_root_launch_binding': args.expected_sts_uid,
            'pod_uid_independently_visible': observed,
            'binding_scope': 'Root verifies actual Kubernetes UID before exec; container also checks POD_UID when exposed.',
            'source_path': str(HERE), 'base': str(BASE)}


def archive_failed_partial(path, check):
    """Preserve an incomplete v2 stream; never trust it as a resumable prefix."""
    path = Path(path)
    if not path.exists() and not path.is_symlink():
        return None
    require(path.is_file() and not path.is_symlink(), 'Unexpected prior partial type')
    archived = path.with_name(path.name + '.v2_failed')
    require(not archived.exists() and not archived.is_symlink(), 'Prior partial archive already exists')
    check()
    size = path.stat().st_size
    # Exclusive hard link plus unlink provides no-overwrite rename semantics.
    os.link(path, archived)
    path.unlink()
    return {'path':str(archived), 'bytes':size, 'not_reused':True}


def reuse_verified(client, yt_path, target, pin, previous, check):
    target = Path(target)
    require(previous['path'] == str(target) and previous['yt_path'] == yt_path and
            previous['bytes'] == pin['bytes'] and previous['sha256'] == pin['sha256'] and
            previous['YT_writes'] == 0, 'Prior completed-file record differs')
    require(target.is_file() and not target.is_symlink() and target.stat().st_size == pin['bytes'],
            'Previous completed-file size/type differs')
    require(int(client.get(yt_path + '/@uncompressed_data_size')) == pin['bytes'], 'Remote input byte count differs')
    revision = int(client.get(yt_path + '/@revision'))
    require(revision == int(previous['revision']), 'Remote revision differs from completed v2 download')
    require(sha(target, check) == pin['sha256'], 'Previous completed-file SHA256 differs')
    require(int(client.get(yt_path + '/@revision')) == revision, 'YT source revision changed during reuse verification')
    return {**previous, 'reused_verified_v2_canonical':True, 'v3_YT_file_bytes_read':0}


def download(client, yt_path, target, pin, check, progress=lambda n: None,
             retry_event=lambda row: None, sleep=time.sleep, client_factory=None,
             worker_count=DOWNLOAD_WORKERS, spool_root=None, retry_backoff_seconds=1.0):
    """Four bounded disk-spooled ranges, joined in file order for full SHA256.

    Worker threads are daemon threads: an expired main-process alarm cannot be
    held alive by a blocked network read. They never publish canonical files or
    status records. Only the main thread assembles and verifies the full file.
    """
    require(1 <= worker_count <= DOWNLOAD_WORKERS, 'At most four download workers')
    target = Path(target)
    temporary = target.with_name(target.name + '.partial')
    require(not target.exists() and not target.is_symlink() and not temporary.exists() and
            not temporary.is_symlink(), 'Fresh download target required')
    target.parent.mkdir(parents=True, exist_ok=True)
    require(int(client.get(yt_path + '/@uncompressed_data_size')) == pin['bytes'], 'Remote input byte count differs')
    revision = int(client.get(yt_path + '/@revision'))
    if spool_root is None:
        spool_root = target.with_name(target.name + '.v3_ranges')
    spool_root = Path(spool_root)
    require(not spool_root.exists() and not spool_root.is_symlink(), 'Fresh range spool required')
    spool_root.mkdir(parents=True)
    worker_count = min(worker_count,max(1,(pin['bytes']+RANGE_BYTES-1)//RANGE_BYTES))
    clients = [client_factory() for _ in range(worker_count)] if client_factory else [client] * worker_count
    require(client_factory is not None or worker_count == 1, 'Parallel ranges require separate YT clients')
    h, count, ranges, retries = hashlib.sha256(), 0, 0, 0
    stopped = threading.Event()
    messages = queue.Queue()

    def fetch(slot, index, offset, length):
        local = clients[slot]
        path = spool_root / (str(index) + '.part')
        for attempt in range(1, RANGE_ATTEMPTS + 1):
            stream = None
            try:
                if stopped.is_set():
                    return
                check()
                require(int(local.get(yt_path + '/@revision')) == revision,
                        'YT source revision changed before range')
                read = 0
                with path.open('wb' if attempt > 1 else 'xb') as output:
                    stream = local.read_file(yt_path, offset=offset, length=length,
                                             enable_read_parallel=False)
                    while read < length:
                        if stopped.is_set():
                            return
                        check()
                        block = stream.read(min(CHUNK, length - read))
                        require(bool(block), 'Short YT range stream')
                        require(read + len(block) <= length, 'YT range exceeded requested bytes')
                        output.write(block)
                        read += len(block)
                    check()
                    require(stream.read(1) == b'', 'YT range has trailing bytes')
                    require(int(local.get(yt_path + '/@revision')) == revision,
                            'YT source revision changed after range')
                    output.flush()
                    os.fsync(output.fileno())
                if stream is not None:
                    try:
                        stream.close()
                    except Exception:
                        pass
                    stream = None
                messages.put(('done',index,path,length,attempt-1))
                return
            except BaseException as error:
                if path.exists():
                    # Only this worker owns this fresh range path.
                    with path.open('wb'):
                        pass
                if type(error) in (RuntimeError,TimeoutError) or not isinstance(error,Exception) or attempt == RANGE_ATTEMPTS:
                    messages.put(('failed',index,'YT_RANGE_TRANSPORT_OR_INTEGRITY_FAILURE'))
                    return
                messages.put(('retry',index,{'offset':offset,'length':length,'failed_attempt':attempt,
                              'failure_type':'YT_RANGE_TRANSPORT_FAILURE',
                              'retries_remaining':RANGE_ATTEMPTS-attempt}))
                if stopped.wait(float(attempt)*retry_backoff_seconds):
                    return
            finally:
                if stream is not None:
                    try:
                        stream.close()
                    except Exception:
                        # Content and revision checks determine success, not a
                        # best-effort HTTP response cleanup message.
                        pass

    try:
        with temporary.open('xb') as output:
            while count < pin['bytes']:
                batch, offset = [], count
                for slot in range(worker_count):
                    if offset >= pin['bytes']:
                        break
                    length = min(RANGE_BYTES,pin['bytes']-offset)
                    batch.append((slot,ranges+slot,offset,length))
                    offset += length
                pending = {row[1] for row in batch}
                finished, threads = {}, []
                for row in batch:
                    thread = threading.Thread(target=fetch,args=row,daemon=True)
                    thread.start()
                    threads.append(thread)
                while pending:
                    check()
                    progress(count)
                    try:
                        message = messages.get(timeout=0.25)
                    except queue.Empty:
                        continue
                    if message[0] == 'retry':
                        retry_event(message[2])
                    elif message[0] == 'failed':
                        stopped.set()
                        raise RuntimeError('YT_RANGE_TRANSPORT_OR_INTEGRITY_FAILURE')
                    else:
                        _, index, path, length, range_retries = message
                        require(index in pending, 'Unexpected completed range index')
                        pending.remove(index)
                        finished[index] = (path,length,range_retries)
                for thread in threads:
                    thread.join(timeout=1)
                    require(not thread.is_alive(), 'Completed range worker did not exit')
                for _, index, offset, length in batch:
                    path, observed_length, range_retries = finished[index]
                    require(offset == count and observed_length == length and path.stat().st_size == length,
                            'Ordered range assembly size/offset mismatch')
                    with path.open('rb') as stream:
                        for block in iter(lambda:stream.read(CHUNK),b''):
                            check()
                            output.write(block)
                            h.update(block)
                            count += len(block)
                            progress(count)
                    path.unlink()
                    ranges += 1
                    retries += range_retries
            output.flush()
            os.fsync(output.fileno())
        require(count == pin['bytes'] and h.hexdigest() == pin['sha256'], 'Downloaded SHA256 differs')
        require(int(client.get(yt_path + '/@revision')) == revision, 'YT source revision changed during read')
        os.link(temporary,target)
        temporary.unlink()
        spool_root.rmdir()
        return {'yt_path':yt_path,'path':str(target),'bytes':count,'sha256':h.hexdigest(),
                'revision':revision,'YT_writes':0,'range_bytes_max':RANGE_BYTES,
                'range_attempts_max':RANGE_ATTEMPTS,'ranges_completed':ranges,'range_retries':retries,
                'max_worker_clients':worker_count,'range_spool_bytes_max':worker_count*RANGE_BYTES,
                'ordered_assembly':True,'request_timeout_ms':REQUEST_TIMEOUT_MS,
                'enable_proxy_discovery':False,'failed_v2_prefix_reused':False}
    finally:
        stopped.set()


def runtime_probe_code():
    # These guards intentionally remain installed until process exit. OGB imports
    # outdated, whose non-daemon version-check thread may run after import returns.
    return """import importlib,json,sys
from unittest import mock

def offline_denied(*args, **kwargs):
 raise RuntimeError('Runtime module probe is offline; network and input forbidden')

_guards=[]
for target in ('socket.socket.connect','socket.socket.connect_ex','socket.create_connection',
               'socket.getaddrinfo','urllib.request.urlopen','builtins.input'):
 guard=mock.patch(target,side_effect=offline_denied)
 guard.start()
 _guards.append(guard)
names=['numpy','scipy','numba','pandas','tqdm','torch','ogb']
out={'python':sys.version,'executable':sys.executable,'modules':{},
     'network_policy':'socket_and_urlopen_blocked_until_subprocess_exit'}
for name in names:
 m=importlib.import_module(name)
 out['modules'][name]={'version':str(getattr(m,'__version__','unknown')),'origin':str(getattr(m,'__file__',''))}
print('PROBE_JSON='+json.dumps(out,sort_keys=True),flush=True)
"""


def main(argv=None):
    args = arguments(argv)
    binding = admission(args)
    OUT.mkdir(parents=True)
    start = time.monotonic()
    deadline = start + args.hours * 3600
    initial_free = shutil.disk_usage(BASE).free
    minimum_free = max(int(args.disk_reserve_gib * 2**30), 4 << 30)
    max_growth = int(args.max_disk_gib * 2**30)
    child = None
    child_identity = None
    phase = 'admitted'
    last_disk_check = 0.0
    last_status = 0.0

    def save(name, value):
        atomic_json(OUT / name, value)

    def status(name, **extra):
        nonlocal phase, last_status
        phase, last_status = name, time.monotonic()
        save('status.json', {'phase': name, 'updated_unix': time.time(), **extra})

    def check(force_disk=False):
        nonlocal last_disk_check
        now = time.monotonic()
        if now >= deadline:
            raise TimeoutError('Finite input bootstrap deadline exceeded')
        if force_disk or now - last_disk_check >= 1:
            free = shutil.disk_usage(BASE).free
            require(free >= minimum_free, 'Disk reserve guard reached')
            require(initial_free - free <= max_growth, '90GiB new disk-use guard reached')
            last_disk_check = now

    def stop_child():
        nonlocal child
        if child is None or child.poll() is not None:
            return
        current = process_identity(child.pid)
        if current is None:
            child.wait(timeout=10)
            return
        require(current['start_ticks'] == child_identity['start_ticks'], 'Owned child PID identity changed')
        try:
            require(os.getpgid(child.pid) == child.pid, 'Owned child process group differs')
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            child.wait(timeout=10)
            return
        try:
            child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=10)

    env = dict(os.environ, PYTHONPATH=str(HERE / 'src'), PYTHONDONTWRITEBYTECODE='1',
               CUDA_VISIBLE_DEVICES='', OMP_NUM_THREADS='4', OPENBLAS_NUM_THREADS='4',
               MKL_NUM_THREADS='4', NUMBA_NUM_THREADS='4', OUTDATED_IGNORE='1',
               NUMBA_CACHE_DIR=str(OUT / 'numba_cache'), PIP_DISABLE_PIP_VERSION_CHECK='1')

    def run(name, argv, capture=False, max_seconds=None):
        nonlocal child, child_identity
        check(True)
        status(name)
        child_deadline = time.monotonic() + max_seconds if max_seconds is not None else deadline
        log_path = OUT / (name + '.log')
        with log_path.open('xb') as log:
            child = subprocess.Popen([str(x) for x in argv], stdin=subprocess.DEVNULL,
                stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
                cwd=HERE / 'src', env=env)
            child_identity = process_identity(child.pid)
            require(child_identity is not None, 'Owned preparation child missing at launch')
            save(name + '.launch.json', {'identity': child_identity, 'argv': [str(x) for x in argv]})
            try:
                while child.poll() is None:
                    check()
                    if time.monotonic() >= child_deadline:
                        raise TimeoutError('Preparation phase deadline exceeded: ' + name)
                    if time.monotonic() - last_status > 30:
                        status(name, child=process_identity(child.pid))
                    time.sleep(1)
            finally:
                stop_child()
        save(name + '.exit.json', {'returncode': child.returncode, 'owned_child_reaped': True})
        require(child.returncode == 0, 'Preparation child failed: ' + name)
        if capture:
            lines = [line[len('PROBE_JSON='):] for line in log_path.read_text().splitlines() if line.startswith('PROBE_JSON=')]
            require(len(lines) == 1, 'Runtime probe did not emit exactly one JSON record')
            return json.loads(lines[0])

    def interrupted(signum, frame):
        raise TimeoutError('Bootstrap interrupted or wall deadline reached')

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGALRM, interrupted)
    signal.setitimer(signal.ITIMER_REAL, args.hours * 3600)
    try:
        status('admitted')
        require(initial_free >= (64 << 30), 'At least64GiB free required for this bounded preparation')
        packet = json.loads((HERE / 'SOURCE_MANIFEST.json').read_text())
        for row in packet['files']:
            rel = PurePosixPath(row['path'])
            require(not rel.is_absolute() and '..' not in rel.parts, 'Unsafe source manifest path')
            file = HERE / row['path']
            require(file.is_file() and not file.is_symlink() and file.stat().st_size == row['bytes'], 'Source payload byte count differs')
            require(sha(file, check) == row['sha256'], 'Source payload SHA256 differs: ' + row['path'])
        c2 = json.loads((HERE / 'EXPECTED_C2_19.json').read_text())
        fr = json.loads((HERE / 'EXPECTED_FRIENDSTER_FULL3.json').read_text())
        wheel = json.loads((HERE / 'EXPECTED_WHEELHOUSE.json').read_text())
        for rel, digest in c2['preparer_source_sha256'].items():
            require(sha(HERE / 'src' / rel, check) == digest, 'Pinned preparer source differs: ' + rel)
        save('plan.json', {'binding': binding, 'source_sha256': sha(Path(__file__), check),
             'source_manifest_sha256':sha(HERE/'SOURCE_MANIFEST.json', check),
             'started_unix': time.time(), 'max_hours': args.hours, 'max_new_disk_bytes': max_growth,
             'disk_reserve_bytes': minimum_free, 'initial_free_disk_bytes': initial_free,
             'unchanged_preparer_sources': c2['preparer_source_sha256'],
             'YT_policy': 'Only get/read_file of existing pinned inputs; no writes/new nodes/chunks.',
             'read_chunk_bytes': CHUNK, 'range_bytes_max':RANGE_BYTES, 'range_attempts_max':RANGE_ATTEMPTS,
             'max_worker_clients':DOWNLOAD_WORKERS,'range_spool_bytes_max':DOWNLOAD_WORKERS*RANGE_BYTES,
             'enable_proxy_discovery':False,
             'request_timeout_ms':REQUEST_TIMEOUT_MS, 'previous_attempt_evidence_preserved':str(PREVIOUS_OUT),
             'stage_optional_wheelhouse': args.stage_wheelhouse,
             'training_or_model_scoring': False, 'automatic_retry': False,
             'bounded_range_transport_retries':True, 'automatic_whole_attempt_retry':False, 'package_installs': 0})
        before_runtime = run('base_before', [args.preparer_python, '-B', '-c', runtime_probe_code()], True, max_seconds=60)
        save('base_before.json', before_runtime)
        for name, version in [('numpy','1.24.4'),('scipy','1.10.1'),('numba','0.58.0'),('ogb','1.3.6')]:
            require(before_runtime['modules'][name]['version'] == version, 'Numerical/preparation version differs: ' + name)
        status('reading_existing_pinned_YT_inputs')
        import yt.wrapper as yt
        def client_factory():
            return yt.YtClient(proxy='jupiter.yt.vk.team',config={
                'proxy':{'request_timeout':REQUEST_TIMEOUT_MS,'heavy_request_timeout':REQUEST_TIMEOUT_MS,
                         'enable_proxy_discovery':False},
                'read_retries':{'enable':False},'read_parallel':{'enable':False}})
        client = client_factory()
        previous = json.loads((PREVIOUS_OUT/'input_download_manifest.json').read_text())
        previous_failure = json.loads((PREVIOUS_OUT/'FAILED.json').read_text())
        require(previous_failure['phase'] == 'reading_existing_file', 'Expected previous input transport failure')
        fr_root = BASE / 'data/friendster/full_csr'
        require(set(previous) == {str(fr_root/'edge_starts.bin')}, 'Unexpected completed previous input set')
        archived_partial = archive_failed_partial(fr_root/'edge_ends.bin.partial', check)
        save('V2_PRESERVATION.json', {'previous_failed_sha256':sha(PREVIOUS_OUT/'FAILED.json',check),
            'previous_download_manifest_sha256':sha(PREVIOUS_OUT/'input_download_manifest.json',check),
            'failed_partial':archived_partial,'previous_evidence_unchanged':True})
        downloads = {}
        def read_one(yt_path, target, pin):
            status('reading_existing_file', yt_path=yt_path, target=str(target), expected_bytes=pin['bytes'])
            def progress(count):
                if time.monotonic() - last_status > 15:
                    status('reading_existing_file', yt_path=yt_path, target=str(target), bytes_read=count,
                           expected_bytes=pin['bytes'])
            if str(target) in previous:
                row = reuse_verified(client, yt_path, target, pin, previous[str(target)], check)
            else:
                def retry_event(row):
                    status('retrying_existing_file_range', yt_path=yt_path, target=str(target), **row)
                row = download(client,yt_path,target,pin,check,progress,retry_event,
                    client_factory=client_factory,worker_count=DOWNLOAD_WORKERS,
                    spool_root=OUT/'range_spool'/hashlib.sha256(str(target).encode()).hexdigest()[:16])
            downloads[str(target)] = row
            save('input_download_manifest.json', downloads)
            return row
        fr_root = BASE / 'data/friendster/full_csr'
        for name in ['edge_starts.bin', 'edge_ends.bin', 'num_nodes.txt']:
            read_one(FRIENDSTER_YT + '/' + name, fr_root / name, fr['files'][name])
        require(int((fr_root / 'num_nodes.txt').read_text()) == fr['num_nodes'], 'Friendster node count differs')
        with (fr_root / 'edge_ends.bin').open('rb') as stream:
            require(struct.unpack('<q', stream.read(8))[0] == fr['stored_entries'], 'Friendster edge header differs')
        require((fr_root / 'edge_starts.bin').stat().st_size == 8 * fr['num_nodes'], 'Friendster offset bytes differ')
        # No timestamp payload is read: absence denotes a binary structural graph.
        atomic_json(fr_root / 'revision_input.json', {'dataset':'friendster','files':fr['files'],
            'public_numeric_identity_pinned': True, 'download_or_canonical_reuse_verified': True,
            'reused_v2_canonical_files':1,
            'timestamps':'not requested or copied; binary structural benchmark'})
        raw = BASE / 'data/citation2/citation-v2.zip'
        raw_pin = {'bytes':c2['recorded_archive_bytes'], 'sha256':c2['recorded_archive_sha256']}
        read_one(RAW_YT, raw, raw_pin)
        if args.stage_wheelhouse:
            read_one(wheel['yt_path'], BASE/'pencil_bridge_wheelhouse_linux_cp310_matched.tgz', wheel)
        save('source_manifest.json', {'files':downloads, 'source_kind':'existing pinned YT objects',
             'official_zip_byte_equality_claimed':False, 'new_YT_nodes':0, 'YT_writes':0})
        run('unchanged_citation2_preparer', [args.preparer_python, '-B', '-u',
            HERE/'src/experiment_configs/seal_revision_2026-11/prepare_citation2.py',
            '--zip', raw, '--root', raw.parent, '--source-manifest', OUT/'source_manifest.json'])
        status('verifying_all19_strict_clean_numeric_payloads')
        prepared = raw.parent / 'prepared'
        observed = []
        for row in c2['files']:
            rel = PurePosixPath(row['path'])
            require(not rel.is_absolute() and '..' not in rel.parts, 'Unsafe expected input path')
            path = prepared / row['path']
            require(path.is_file() and not path.is_symlink() and path.stat().st_size == row['bytes'], 'Prepared byte count differs: ' + row['path'])
            require(sha(path, check) == row['sha256'], 'Prepared SHA256 differs: ' + row['path'])
            observed.append(row)
        require(len(observed) == 19, 'Expected exactly19 prepared payloads')
        save('ACTUAL_C2_19_IDENTITY.json', {'all19_numeric_payloads_exact':True, 'files':observed,
             'prepared_root':str(prepared), 'fresh_metadata_paths_and_timestamps':True})
        save('ACTUAL_FRIENDSTER_FULL3_IDENTITY.json', {'all3_numeric_payloads_exact':True,
             'files':fr['files'], 'root':str(fr_root), 'download_records':{k:v for k,v in downloads.items() if k.startswith(str(fr_root)+'/')}})
        for rel, digest in c2['preparer_source_sha256'].items():
            require(sha(HERE/'src'/rel, check) == digest, 'Preparer source changed during execution')
        after_runtime = run('base_after', [args.preparer_python, '-B', '-c', runtime_probe_code()], True, max_seconds=60)
        save('base_after.json', after_runtime)
        require(before_runtime == after_runtime, 'Base environment changed during preparation')
        check(True)
        # These final canonical markers are published only after both inputs pass.
        atomic_json(BASE/'data/input_download_manifest.json', downloads)
        atomic_json(BASE/'data/friendster_DOWNLOAD_COMPLETE.json', {'dataset':'friendster',
            'all_pinned_files_complete':True, 'public_numeric_identity_verified':True,
            'full_graph_root':str(fr_root), 'new_YT_nodes':0, 'YT_writes':0})
        save('COMPLETE.json', {'input_preparation_complete':True, 'all19_C2_numeric_payloads_exact':True,
             'all3_Friendster_numeric_payloads_exact':True, 'friendster_root':str(fr_root),
             'citation2_prepared_root':str(prepared), 'base_environment_unchanged':True,
             'package_installs':0, 'YT_writes':0, 'new_YT_nodes':0, 'new_YT_chunks':0,
             'prepared_inputs_ready_for_separately_owned_scientific_controller':True,
             'preparation_child_reaped': child is not None and child.poll() is not None,
             'elapsed_seconds':time.monotonic()-start, 'finished_unix':time.time()})
        status('complete')
        return 0
    except BaseException as error:
        stop_child()
        # Avoid serializing arbitrary client exception payloads or configuration.
        message = str(error)[:700] if type(error).__module__ == 'builtins' else 'External-client failure; no exception configuration serialized.'
        save('FAILED.json', {'phase':phase, 'error_type':type(error).__name__, 'message':message,
             'new_YT_nodes':0, 'YT_writes':0, 'scientific_jobs_started':0, 'automatic_retry':False})
        status('failed', error_type=type(error).__name__)
        print('Input bootstrap failed: ' + type(error).__name__, file=sys.stderr)
        return 1
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)


if __name__ == '__main__':
    raise SystemExit(main())
