#!/usr/bin/env python3
"""One bounded read-only ingress of the three pinned Friendster payloads.

The successful E23 four-range transport is reused unchanged. No science,
package installation, graph conversion, YT mutation or token readback occurs.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import shutil
import signal
import socket
import struct
import sys
import time

HERE = Path(__file__).resolve().parent
BASE = Path('/home/jovyan/seal_native_lifecycle_20261126')
OUT = BASE / 'ingress'
DATA = BASE / 'data/friendster/full_csr'
HOST = 'seal-native-pvc-20261126-0'
YT_SOURCE = '//home/ucp-research/projects/graph_baselines/friendster/csr'
LIMIT = 40 * (1 << 30)
RESERVE = 4 * (1 << 30)

def require(value, message):
    if not value:
        raise RuntimeError(message)

def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()

def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('w') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)

def versions():
    return {name: importlib.metadata.version(name) for name in
            ('numpy', 'scipy', 'numba', 'torch', 'torch-geometric')}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pod-uid', required=True)
    parser.add_argument('--sts-uid', required=True)
    parser.add_argument('--unix-uid', type=int, required=True)
    parser.add_argument('--manifest-sha256', required=True)
    args = parser.parse_args()
    require(sys.platform == 'linux' and socket.gethostname() == HOST, 'Pinned Linux hostname required')
    require(os.getuid() == args.unix_uid and args.unix_uid >= 0, 'Pinned actual image Unix UID required')
    require(os.environ.get('POD_UID') == args.pod_uid and len(args.pod_uid) == 36
            and len(args.sts_uid) == 36, 'Root-attested Pod/STS UIDs and visible downward Pod UID required')
    require(BASE.resolve() == BASE and HERE == BASE / 'ingress_source', 'Fresh canonical source/base required')
    require(OUT.resolve() == OUT and DATA.resolve() == DATA, 'Canonical result and data ancestors required')
    require(not OUT.exists() and not os.path.lexists(DATA), 'Preserve prior evidence/data; no whole-run retry')
    manifest_path = HERE / 'SOURCE_MANIFEST.json'
    require(manifest_path.is_file() and not manifest_path.is_symlink(), 'Regular source manifest required')
    require(sha(manifest_path) == args.manifest_sha256, 'Pinned source manifest SHA required')
    manifest = json.loads(manifest_path.read_text())
    for name, row in manifest['files'].items():
        p = HERE / name
        require(p.is_file() and not p.is_symlink() and p.resolve().parent == HERE
                and p.stat().st_size == row['bytes'] and sha(p) == row['sha256'], 'Source packet changed')
    pins = json.loads((HERE / 'EXPECTED_FRIENDSTER_FULL3.json').read_text())
    require(set(pins['files']) == {'num_nodes.txt', 'edge_starts.bin', 'edge_ends.bin'}
            and pins['num_nodes'] == 65608366 and pins['stored_entries'] == 3612134270,
            'Exact original Friendster numeric contract required')
    require(shutil.disk_usage(BASE).free > LIMIT + RESERVE, 'Forty GiB ingress budget plus reserve required')
    OUT.mkdir()
    started = time.monotonic()
    deadline = started + 5400
    free_before = shutil.disk_usage(BASE).free
    last_disk_check, last_progress = 0.0, 0.0
    phase = 'admitted'
    def check():
        nonlocal last_disk_check
        require(time.monotonic() < deadline, 'Ingress deadline exceeded')
        if time.monotonic() - last_disk_check > 1:
            free = shutil.disk_usage(BASE).free
            require(free >= RESERVE and free_before - free <= LIMIT, 'Ingress disk guard')
            last_disk_check = time.monotonic()
    def alarm(*_):
        raise TimeoutError('Ingress deadline')
    signal.signal(signal.SIGALRM, alarm)
    signal.alarm(5400)
    before = versions()
    save(OUT / 'plan.json', dict(pod_uid=args.pod_uid, sts_uid=args.sts_uid,
        unix_uid=os.getuid(), hostname=HOST, source_manifest_sha256=args.manifest_sha256,
        data_root=str(DATA), source_YT=YT_SOURCE, max_seconds=5400,
        max_disk_growth_bytes=LIMIT, reserve_bytes=RESERVE, expected_files=pins['files'],
        package_installs=0, YT_writes=0, scientific_jobs_started=0, automatic_whole_retry=False,
        version_before=before, started_unix=time.time()))
    transport_spec = importlib.util.spec_from_file_location('frozen_e23_transport', HERE / 'frozen_range_transport_v3.py')
    transport = importlib.util.module_from_spec(transport_spec)
    transport_spec.loader.exec_module(transport)
    downloads = {}
    try:
        import yt.wrapper as yt
        def client_factory():
            return yt.YtClient(proxy='jupiter.yt.vk.team', config={
                'proxy': {'request_timeout': 120000, 'heavy_request_timeout': 120000,
                          'enable_proxy_discovery': False},
                'read_retries': {'enable': False}, 'read_parallel': {'enable': False}})
        client = client_factory()
        for name in ('edge_starts.bin', 'edge_ends.bin', 'num_nodes.txt'):
            phase = 'reading_' + name
            def progress(count):
                nonlocal last_progress
                if time.monotonic() - last_progress > 10:
                    save(OUT / 'status.json', dict(phase=phase, file=name, bytes_read=count,
                        expected_bytes=pins['files'][name]['bytes'], observed_unix=time.time()))
                    last_progress = time.monotonic()
            row = transport.download(client, YT_SOURCE + '/' + name, DATA / name,
                pins['files'][name], check, progress,
                lambda event: save(OUT / 'last_bounded_transport_retry.json', dict(file=name, **event)),
                client_factory=client_factory, worker_count=4,
                spool_root=OUT / ('ranges_' + name))
            downloads[name] = row
            save(OUT / 'downloads.json', downloads)
        require(int((DATA / 'num_nodes.txt').read_text()) == pins['num_nodes'], 'Node count differs')
        with (DATA / 'edge_ends.bin').open('rb') as stream:
            require(struct.unpack('<q', stream.read(8))[0] == pins['stored_entries'], 'Edge header differs')
        with (DATA / 'edge_starts.bin').open('rb') as stream:
            require(struct.unpack('<q', stream.read(8))[0] == 0, 'First offset differs')
            stream.seek(-8, 2)
            require(0 <= struct.unpack('<q', stream.read(8))[0] <= pins['stored_entries'], 'Last offset invalid')
        after = versions()
        require(before == after, 'Runtime package versions changed')
        check()
        save(DATA / 'revision_input.json', dict(dataset='friendster', files=pins['files'],
            all3_numeric_payloads_exact=True, timestamps='not requested; binary structural graph'))
        save(OUT / 'COMPLETE.json', dict(success=True, all3_numeric_payloads_exact=True,
            files=pins['files'], downloads=downloads, data_root=str(DATA),
            elapsed_seconds=time.monotonic() - started, completed_unix=time.time(),
            version_before=before, version_after=after, base_environment_unchanged=True,
            scientific_jobs_started=0, package_installs=0, YT_writes=0, new_YT_nodes=0, new_YT_chunks=0))
        save(OUT / 'status.json', dict(phase='complete', observed_unix=time.time()))
        return 0
    except BaseException as error:
        # External client exception payload/config may contain secrets: retain type only.
        save(OUT / 'FAILED.json', dict(phase=phase, error_type=type(error).__name__,
            observed_unix=time.time(), scientific_jobs_started=0, YT_writes=0, automatic_whole_retry=False))
        save(OUT / 'status.json', dict(phase='failed', observed_unix=time.time()))
        return 1
    finally:
        signal.alarm(0)

if __name__ == '__main__':
    raise SystemExit(main())
