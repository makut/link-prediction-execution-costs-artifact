"""One local fake-science lifecycle; no Linux/graphs/GPU/YT science implied."""
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import unittest

import outer_e23 as outer


class FakeSupport:
    """Real local subprocess/wait, injected process inventory for non-Linux QA."""
    @staticmethod
    def run_owned(argv, log, *, cwd, timeout, popen):
        with log.open('x') as stream:
            child = popen(argv, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT,
                          stdin=subprocess.DEVNULL, close_fds=True, start_new_session=True)
            code = child.wait(timeout=timeout)
        return dict(pid=child.pid, returncode=code, timed_out=False,
                    orphan_cleanup=False, owned_tree_quiescent=True)


class FakeClient:
    def __init__(self):
        self.payload = None
        self.calls = []
        self.committed = False

    def exists(self, path):
        return path == outer.YT_ROOT

    def Transaction(self, timeout):
        self.calls.append(('transaction', timeout))
        return self

    def __enter__(self):
        return self

    def __exit__(self, kind, value, tb):
        self.committed = kind is None

    def create(self, kind, path, recursive):
        self.calls.append(('create', kind, path, recursive))

    def write_file(self, path, stream, file_writer):
        self.calls.append(('write', path, file_writer))
        self.payload = stream.read()

    def get(self, path):
        return 1 if path.endswith('/@chunk_count') else len(self.payload)

    def read_file(self, path):
        return io.BytesIO(self.payload)


class FakeLifecycle(unittest.TestCase):
    def test_real_fake_child_exit_provenance_then_single_fake_upload(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            packet, evidence = root / 'packet', root / 'evidence'
            packet.mkdir()
            evidence.mkdir()
            fake_source = packet / 'run_pipeline_repeats.py'
            fake_source.write_text('import time\nprint("fake science only")\ntime.sleep(.1)\n')
            contract = dict(packet=str(packet), packet_manifest_sha256='fake-local-manifest')
            launch, result = outer.supervise_child(contract, FakeSupport(), 10, evidence,
                argv=[sys.executable, '-B', str(fake_source)],
                reader=lambda pid: dict(pid=pid, start_ticks=123456, state='R', argv=[str(fake_source)]))
            self.assertGreater(launch['pid'], 0)
            self.assertEqual(result['pid'], launch['pid'])
            self.assertTrue(result['actual_wait_returned'])
            self.assertEqual(result['returncode'], 0)
            self.assertTrue(result['owned_tree_quiescent'])
            self.assertEqual(outer.read(evidence / 'child_launch.json')['start_ticks'], 123456)
            self.assertTrue(outer.quiet(launch, reader=lambda pid: None)['quiescent'])
            with self.assertRaisesRegex(RuntimeError, 'PID reused'):
                outer.quiet(launch, reader=lambda pid: dict(start_ticks=999, state='R'))
            fixture = root / 'tiny_fixture'
            fixture.mkdir()
            pairs = fixture / 'pairs.npy'
            pairs.write_bytes(b'fake fixture workload for packaging lifecycle only')
            report = dict(benchmark_version=4, graph={'path': 'fixture'}, manifest=dict(
                path=str(pairs.resolve()), sha256=outer.sha(pairs), rows=128,
                positive_occurrences=64, columns=['src', 'dst', 'label']))
            (fixture / 'report.json').write_text(json.dumps(report))
            self.assertEqual(outer.fixture_pair_identity(pairs)['sha256'], outer.sha(pairs))
            pairs.write_bytes(b'tampered tiny fixture workload')
            with self.assertRaisesRegex(RuntimeError, 'tiny fixture workload/report identity'):
                outer.fixture_pair_identity(pairs)
            archive = root / 'fake-only.tgz'
            files = {'e23/envelope/' + p.name: p for p in evidence.iterdir()}
            receipt = outer.archive_results(archive, files)
            self.assertTrue(receipt['all_whole_member_hashes_verified'])
            with tarfile.open(archive, 'r:gz') as tar:
                self.assertIn('e23/envelope/child_exit.json', tar.getnames())
            client = FakeClient()
            pointer = outer.upload_once(archive, receipt, outer.YT_FINAL, client=client)
            self.assertEqual(sum(c[0] == 'write' for c in client.calls), 1)
            self.assertEqual(sum(c[0] == 'create' for c in client.calls), 1)
            self.assertTrue(client.committed and pointer['readback_verified'])
            self.assertEqual(pointer['sha256'], receipt['sha256'])
            self.assertEqual(pointer['chunk_count'], 1)
            with self.assertRaisesRegex(RuntimeError, 'only pinned'):
                outer.upload_once(archive, receipt, outer.YT_FINAL + '-other', client=client)


if __name__ == '__main__':
    unittest.main()
