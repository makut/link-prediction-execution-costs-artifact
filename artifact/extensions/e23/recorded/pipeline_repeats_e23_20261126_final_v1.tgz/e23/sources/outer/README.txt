Detached E23 outer envelope, source-only preparation

This package contains no graph, credentials, cluster commands or scheduler
client. It never creates/deletes/scales a pod or StatefulSet. Only root may
transport and launch it, after checking the actual current Kubernetes Pod UID
and StatefulSet UID against CONTRACT.json immediately before exec. A matching
hostname alone does not establish a Kubernetes UID. The container independently
checks hostname, Unix UID, canonical source/output paths and POD_UID if exposed.
The latter is not exposed by the currently admitted pod manifest, so its UID
binding is explicitly root-attested rather than independently rediscovered.

Launcher: python -B -u launch_outer_e23.py --source-manifest-sha256 MANIFEST_SHA
Use the pinned /opt/python/bin/python3. Launch from the contract's outer_source.
The launcher opens an exclusive log, starts a new detached session with DEVNULL
stdin and writes actual PID/start_ticks/source/argv/admission receipt. No retry.

The envelope waits at most 90 minutes for the exact pinned bootstrap receipt,
source, Pod/STS/Unix UID admission, all19 strict-clean Citation2 and all3 full
Friendster payload receipts, unchanged runtime and preparer source identities,
zero input-stage installs/YT writes, genuine COMPLETE, final status and actual
bootstrap PID/start quiescence (absent or zombie). The bootstrap was not launched
as its child: its wait returncode is unknown and is never invented. A bootstrap
failure or exit without COMPLETE prevents the scientific launch.

It then launches the unchanged E23 packet into a FRESH_OUT. The total outer
budget is six hours including the bootstrap wait, with 15 minutes reserved for
archive/persistence; the runner gets the remaining bounded time minus 30 seconds.
There is no subset selection or automatic restart: all40 jobs, including the36
timing jobs, are mandatory for scientific success. Original 180GiB CPU, 24GiB
Torch allocator and 2GiB scientific-output guards remain unchanged. All worker
signals belong only to observed descendant process groups with confirmed PID,
start_ticks and pgid identity. No foreign processes are signaled.

The successful runner marker is insufficient by itself. Before packaging, the
envelope obtains the actual child wait returncode0, no timeout/orphan cleanup,
owned-tree quiescence, the exact child PID/start/source/argv receipt, the genuine
successful full-grid terminal/summary, expected GPU UUID and an available
exclusive flock on PUBLIC_SYSTEMS_RUNNING.lock. The persistent lock file is
retained; its presence is not interpreted as a live lock.

The archive contains the entire small frozen source packet and outer sources,
public pair workloads, small scientific JSON/JSONL/log outputs, pinned bootstrap
receipts and actual post-child-exit envelope receipts. Numba caches, graph input
trees, environments, models and secrets are excluded. Bounds: at most4096 regular
files,32MiB each,384MiB raw including manifest,128MiB compressed. Every archived
member is streamed and verified against the complete internal SHA256 manifest.
The only extra binary preflight files allowed are jobs/guard_refusal/pairs.npy
and jobs/gpu_fixture/pairs.npy, each at most4096bytes and bound to its unchanged
V4 fixture report.manifest SHA, canonical path,128rows and64positive occurrences.
No archive is created until science and child-lifecycle verification succeed.

Only one final YT target in CONTRACT.json is permitted, in the already existing
authorized artifact parent. There are no periodic remote writes, overwrites,
recursive parent creation or automatic retries. A transaction creates one file,
performs one nonparallel write, requires exactly one data chunk and matching byte
count, streams a whole-file SHA256 readback and commits only on equality. The
writer desired_chunk_size512MiB is above the128MiB compressed archive cap.
The client uses bounded requests and disables write/read retries and parallelism.
The second envelope uses request_timeout120000 and heavy_request_timeout120000
with proxy.enable_proxy_discovery=False, as selected by the root transport probe.
On upload failure local archive/evidence remain; no second target or retry is made.

The archive proves scientific/child completion BEFORE upload. Its own upload
pointer and the final outer COMPLETE necessarily remain outside that archive.
Root must separately collect the actual final outer COMPLETE, source-bound outer
launch receipt and actual outer PID/start quiescence (and wait returncode when
available). An uploaded science archive does not claim the outer process has
already exited. The envelope never self-releases the GPU/StatefulSet.

Local QA: exactly one fake-science lifecycle test. It launches and waits for a
real tiny local subprocess, uses an injected synthetic /proc identity on macOS,
verifies refusal of PID reuse, packages actual launch/exit receipts, verifies the
whole archive and exercises a fake one-write/one-chunk readback transaction.
This is supervisor QA only, not a real GPU/graph/scientific execution or YT write.
Python3.10 AST compatibility is also checked. Frozen E23 scientific sources and
published artifact v0.5.0 are unchanged.

Second outer attempt: previous outer and bootstrap attempts remain preserved.
The first outer attempt refused scientific launch after the v2 bootstrap read
timeout. This separately admitted attempt requires the pinned manual v3 input
bootstrap and uses fresh outer source/evidence/launch paths. Its science output
and sole final YT target remain unchanged and must still be absent. Exact v3
source, receipt, PID and start_ticks are frozen in this attempt CONTRACT.json.
Its runtime-code changes are the final uploader proxy configuration stated
above and the exact tiny preflight-workload packaging whitelist. The scientific
runner and protocol remain frozen and unchanged.
