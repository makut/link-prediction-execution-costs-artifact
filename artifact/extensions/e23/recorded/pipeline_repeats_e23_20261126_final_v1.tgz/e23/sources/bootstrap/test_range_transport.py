"""Five focused v3 transport tests; no real YT, graph, dependency or cluster work."""
from pathlib import Path
import hashlib
import io
import tempfile
import unittest
from unittest.mock import patch

import input_bootstrap as b


class Stream(io.BytesIO):
    def __init__(self, data, fail=False):
        super().__init__(data)
        self.fail = fail
        self.reads = 0

    def read(self, n):
        assert 0 < n <= b.CHUNK
        self.reads += 1
        if self.fail and self.reads == 2:
            raise OSError('simulated bounded transport failure')
        return super().read(n)


class Client:
    def __init__(self, payload, fail_once=False, fail_always=False, mutate=False):
        self.payload = payload
        self.calls = []
        self.fail_once = fail_once
        self.fail_always = fail_always
        self.mutate = mutate
        self.completed_reads = 0

    def get(self, key):
        if key.endswith('/@uncompressed_data_size'):
            return len(self.payload)
        assert key.endswith('/@revision')
        return 7 + int(self.mutate and bool(self.calls))

    def read_file(self, key, *, offset, length, enable_read_parallel):
        assert enable_read_parallel is False
        assert length <= b.RANGE_BYTES
        failed = self.fail_always or (self.fail_once and offset == b.RANGE_BYTES and
                    not any(x[0] == offset for x in self.calls))
        self.calls.append((offset, length))
        return Stream(self.payload[offset:offset+length], failed)


def pin(payload):
    return {'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}


class RangeTransportTests(unittest.TestCase):
    def setUp(self):
        self.limits = patch.multiple(b, RANGE_BYTES=11, CHUNK=4)
        self.limits.start()
        self.addCleanup(self.limits.stop)

    def test_retried_range_truncates_partial_and_keeps_exact_hash(self):
        payload = b'bounded range file transport' * 3
        client = Client(payload, fail_once=True)
        events = []
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder)/'input.bin'
            result = b.download(client,'//existing/file',target,pin(payload),lambda:None,
                                retry_event=events.append,worker_count=1,retry_backoff_seconds=0)
            self.assertEqual(target.read_bytes(),payload)
            self.assertEqual(result['range_retries'],1)
            self.assertEqual([x[0]for x in client.calls].count(11),2)
            self.assertEqual(len(events),1)
            self.assertFalse(target.with_name('input.bin.partial').exists())

    def test_three_failed_attempts_never_publish_or_retry_forever(self):
        payload = b'bounded payload'
        client = Client(payload,fail_always=True)
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder)/'input.bin'
            with self.assertRaisesRegex(RuntimeError,'YT_RANGE_TRANSPORT_OR_INTEGRITY_FAILURE'):
                b.download(client,'//existing/file',target,pin(payload),lambda:None,
                           worker_count=1,retry_backoff_seconds=0)
            self.assertFalse(target.exists())
            self.assertEqual(target.with_name('input.bin.partial').stat().st_size,0)
            self.assertEqual(len(client.calls),3)

    def test_revision_change_is_integrity_failure_without_retry(self):
        payload = b'bounded payload'
        client = Client(payload,mutate=True)
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder)/'input.bin'
            with self.assertRaisesRegex(RuntimeError,'YT_RANGE_TRANSPORT_OR_INTEGRITY_FAILURE'):
                b.download(client,'//existing/file',target,pin(payload),lambda:None,
                           worker_count=1,retry_backoff_seconds=0)
            self.assertFalse(target.exists())
            self.assertEqual(len(client.calls),1)

    def test_four_clients_spool_and_assemble_in_order(self):
        payload = b'parallel bounded ranges' * 7
        client = Client(payload)
        workers = []
        def factory():
            result = Client(payload)
            workers.append(result)
            return result
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder)/'input.bin'
            spool = Path(folder)/'spool'
            result = b.download(client,'//existing/file',target,pin(payload),lambda:None,
                client_factory=factory,worker_count=4,spool_root=spool,retry_backoff_seconds=0)
            self.assertEqual(target.read_bytes(),payload)
            self.assertEqual(len(workers),4)
            self.assertEqual(result['max_worker_clients'],4)
            self.assertTrue(result['ordered_assembly'])
            self.assertFalse(spool.exists())
            self.assertEqual(sum(len(x.calls)for x in workers),result['ranges_completed'])

    def test_completed_v2_reuse_and_failed_partial_preservation(self):
        payload = b'previously verified offsets'
        client = Client(payload)
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder)/'edge_starts.bin'
            target.write_bytes(payload)
            prior = dict(pin(payload),path=str(target),yt_path='//existing/file',revision=7,YT_writes=0)
            result = b.reuse_verified(client,'//existing/file',target,pin(payload),prior,lambda:None)
            self.assertTrue(result['reused_verified_v2_canonical'])
            self.assertEqual(client.calls,[])
            partial = Path(folder)/'edge_ends.bin.partial'
            partial.write_bytes(b'untrusted failed prefix')
            receipt = b.archive_failed_partial(partial,lambda:None)
            self.assertFalse(partial.exists())
            self.assertEqual(Path(receipt['path']).read_bytes(),b'untrusted failed prefix')
            self.assertEqual(target.read_bytes(),payload)
            self.assertTrue(receipt['not_reused'])


if __name__ == '__main__':
    unittest.main()
