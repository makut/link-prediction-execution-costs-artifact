V3 is one manually admitted new input-preparation attempt, not an automatic retry or a scientific experiment. V1/V2 source and failure evidence remain unchanged.

Remote HERE: /home/jovyan/seal_revision_20261124/revision_inputs_20261126_v3_code
Remote OUT: BASE/results/revision_gpu_inputs_20261126_v3
Log/launch: BASE/revision_input_bootstrap_20261126_v3.log and .launch.json
Pod/StatefulSet UID bindings, Unix UID0, base environment and all four Citation2 preparation sources are unchanged.

Launch:
/opt/python/bin/python3 -B /home/jovyan/seal_revision_20261124/revision_inputs_20261126_v3_code/launch_input_bootstrap.py --expected-uid 0 --expected-pod-uid 98718cc9-f0cb-47b7-b54f-d66f737f1337 --expected-sts-uid 8da7f488-7109-4d58-80db-8b8fdf7f3c13 --hours 1.5 --max-disk-gib 90 --disk-reserve-gib 4

The existing canonical Friendster edge_starts.bin is reused only after exact size/SHA256 and remote revision equality with the original completed V2 receipt. An existing edge_ends.bin.partial, if any, is preserved with suffix .v2_failed using an exclusive no-overwrite link/unlink; its prefix is never trusted or reused. Prior V2 FAILED/download receipts are read and pinned, not modified. Other prior/canonical input paths are refused.

Read-only ingress: up to four separate worker YtClients and daemon threads fetch 256MiB ranges to disk spools, reading at most1MiB into memory at a time. At most four ranges are spooled per batch, then copied in order to the owned whole-file partial and included in its final SHA256. Every range checks the original YT revision before/after; the whole file checks it again before publication. Full size/SHA256 are mandatory. No 256MiB in-memory buffers are used. Up to three attempts per range total, with1/2second backoff. Runtime client errors become fixed failure-type strings; dynamic YT exception text is not serialized. The nested proxy config disables proxy discovery and sets both request and heavy request timeouts to120000ms; internal read retries and read_parallel are disabled.

Main-thread alarm/deadline is at most90minutes, with the unchanged sampled90GiB new-disk-use guard,4GiB reserve and64GiB initial-free admission. Daemon threads cannot hold process exit alive. Main-thread disk/deadline checks continue while waiting for ranges; workers also check between1MiB reads. Their blocked reads may remain until process exit or request timeout, but cannot publish canonical files or launch science. Canonical publication occurs only in the main thread after full verification. COMPLETE.json retains all3Friendster/all19Citation2/base-unchanged/child-reaped/zero-YT-write keys.

No new YT nodes/chunks, operations, writes or graph copies are created. No scoring, training, package installation or dependency changes occur. Runtime probe code is unchanged from the V2 actual Linux import test. Five focused tiny local transport tests passed, including actual thread/disk spooling and ordered assembly; no old source-fuzz/model/graph tests were rerun. Root owns all actual cluster and YT probes and launch.
