"""Detach exactly one admitted input bootstrap; never start scientific jobs."""
from pathlib import Path
import json
import os
import subprocess
import sys
import time

import input_bootstrap as bootstrap


def main():
    args = bootstrap.arguments()
    admission = bootstrap.admission(args)
    log_path = bootstrap.BASE / 'revision_input_bootstrap_20261126_v3.log'
    receipt_path = bootstrap.BASE / 'revision_input_bootstrap_20261126_v3.launch.json'
    bootstrap.require(not log_path.exists() and not receipt_path.exists(), 'Fresh one-shot launch required')
    argv = [sys.executable, '-B', '-u', str(bootstrap.HERE / 'input_bootstrap.py'), *sys.argv[1:]]
    with log_path.open('xb') as log:
        child = subprocess.Popen(argv, cwd=bootstrap.HERE, stdin=subprocess.DEVNULL,
            stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
            env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', CUDA_VISIBLE_DEVICES='',
                     OUTDATED_IGNORE='1'))
    identity = bootstrap.process_identity(child.pid)
    bootstrap.require(identity is not None, 'Detached bootstrap disappeared at launch')
    bootstrap.atomic_json(receipt_path, {'pid':child.pid, 'start_ticks':identity['start_ticks'],
        'argv':argv, 'entrypoint':str(bootstrap.HERE/'input_bootstrap.py'),
        'source_sha256':bootstrap.sha(bootstrap.HERE/'input_bootstrap.py'),
        'started_unix':time.time(), 'stdin_dependency':False, 'detached_session':True,
        'log':str(log_path), 'output':str(bootstrap.OUT), 'admission':admission,
        'scientific_jobs_started':0, 'automatic_retry':False})
    print(json.dumps({'pid':child.pid, 'start_ticks':identity['start_ticks'],
        'receipt':str(receipt_path), 'status':str(bootstrap.OUT/'status.json'),
        'completion':str(bootstrap.OUT/'COMPLETE.json')}))


if __name__ == '__main__':
    main()
